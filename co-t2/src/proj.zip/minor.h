/* Flags */
#define F_CONST   0b0000001
#define F_PUBLIC  0b0000010
#define F_FORWARD 0b0000100
#define F_FUNC    0b0001000 
#define F_INTLIT  0b0010000
#define F_ZERO    0b0100000
#define F_GLOBAL  0b1000000